import org.scalatest.FunSuite

/**
  * Created by nhphung on 4/28/17.
  */
class LexerSuite extends FunSuite with TestLexer {

  test("a simple identifier") {
    val input = "abc"
    val expect = "abc,<EOF>"
    assert(checkLex(input,expect,1))
  }
  test("half function declare") {
    val input = "main int {"
    val expect = """main,int,{,<EOF>"""
    assert(checkLex(input,expect,2))
  }
  test("open and close parentheses"){
    val input = "} int main {"
    val expect = """},int,main,{,<EOF>"""
    assert(checkLex(input,expect,3))
  }
  test("2 ID tab skip"){
    val input = "abc 			def"
    val expect = "abc,def,<EOF>"
    assert(checkLex(input,expect,4))
  }
  test("new line") {
    val input = """abc
def			ghi"""
    val expect = "abc,def,ghi,<EOF>"
    assert(checkLex(input,expect,5))
  }
  test("id digit") {
    val input = """abc123
def			ghi"""
    val expect = "abc123,def,ghi,<EOF>"
    assert(checkLex(input,expect,6))
  }
  test("special symbol") {
    val input = """abc123+
def			ghi"""
    val expect = "abc123,+,def,ghi,<EOF>"
    assert(checkLex(input,expect,7))
  }
  test("special symbol continue") {
    val input = """abc123+{
def			ghi"""
    val expect = """abc123,+,{,def,ghi,<EOF>"""
    assert(checkLex(input,expect,8))
  }
  test("comment") {
    val input = """abc123 //abcd newline here
	"""
    val expect = """abc123,<EOF>"""
    assert(checkLex(input,expect,9))
  }
  test("comment block") {
    val input = """abc123 /*abcd newline here
	ashdhash
	asdasda*/"""
    val expect = """abc123,<EOF>"""
    assert(checkLex(input,expect,10))
  }
  test("test keyword") {
    val input = """abc123 /*abcd newline here
	ashdhash
	asdasda*/
	while()
	do{
	}"""
    val expect = """abc123,while,(,),do,{,},<EOF>"""
    assert(checkLex(input,expect,11))
  }
  test("string") {
    val input = "\"   123abc\""
    val expect = "\"   123abc\",<EOF>"
    assert(checkLex(input,expect,12))
  }
  test("unclose string") {
    val input = "\"123abcd"
    val expect = "Unclosed string: \"123abcd"  //"Unclosed string: " from "UNCLOSE_STRING"
    assert(checkLex(input,expect,13))
  }
  test("error token") {
    val input = "~.sfa"      //"ErrorToken " from "ERROR_CHAR"
    val expect = "ErrorToken ~"
    assert(checkLex(input,expect,14))
  }
  /*******
  test("illegal escape in string") {
    val input = "\"\r\n\\\\\""
    val expect = "abcd"
    assert(checkLex(input,expect,15))
  }
  ******/
}