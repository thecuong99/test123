import org.scalatest.FunSuite

/**
  * Created by nhphung on 4/28/17.
  */
class ParserSuite  extends FunSuite with TestParser {

  test("a simple program") {
    val input = "int main () {}"
    val expect = "sucessful"
    assert(checkRec(input,expect,101))
  }
  test("more complex program") {
    val input ="""int main () {
	putIntLn(4);
  }"""
    val expect ="sucessful"
    assert(checkRec(input,expect,102))
  }
  test("wrong program"){
    val input = "} int main {"
    val expect = "Error on line 1 col 1: }"
    assert(checkRec(input,expect,103))
  }
  test("complex program more var") {
    val input ="""float a;
	int main () {
	putIntLn(4);
  }"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,104))
  }
  test("more functions no parameters") {
    val input ="""float a;
	void abc(){}
	int main () {
	putIntLn(4);
  }"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,105))
  }
  test("more functions with parameters") {
    val input ="""float a;
	void abc(int X){}
	int main () {
	putIntLn(4);
  }"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,106))
  }
  test("assignment op in functions") {
    val input ="""
	float a;
	void abc(){ a = 3;}
	int main () {
		putIntLn(4);
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,107))
  }
  test("call functions") {
    val input ="""
	float a;
	void abc(){ a = 3;}
	int main () {
		putIntLn(4);
		abc();
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,108))
  }
  test("branch IF") {
    val input ="""
	float a;
	void abc(){ a = 3;}
	int main () {
		putIntLn(4);
		abc();
		if (a = 1) {
		}
		
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,109))
  }
  test("command return") {
    val input ="""
	float a;
	float abc(){
	a = 3;
	return 2 + 4;
	}
	int main () {
		putIntLn(4);
		abc();
		if (a = 1) {
		}
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,110))
  }
  test("test repeat do while") {
    val input ="""
	float a;
	float abc(){
	a = 3;
	do {
	} while a >= 6;
	return 2 + 4;
	}
	int main () {
		putIntLn(4);
		abc();
		if (a = 1) {
		}
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,111))
  }
  /*******
  test("test error") {
    val input ="""
	float a;
	int     
	float abc(){
	a = 3;
	return 2 + 4;
	}
	int main () {
		putIntLn(4);
		abc();
		if (a = 1) {
		}
		do {
		}
		while a >= 6;
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,112))
  }
  *******/
  
}