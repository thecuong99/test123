import org.scalatest.FunSuite

/**
  * Created by nhphung on 4/28/17.
  */
class ParserSuite  extends FunSuite with TestParser {

  test("a simple program") {
    val input = "int main () {}"
    val expect = "sucessful"
    assert(checkRec(input,expect,101))
  }
  test("more complex program") {
    val input ="""int main () {
	putIntLn(4);
  }"""
    val expect ="sucessful"
    assert(checkRec(input,expect,102))
  }
  test("wrong program"){
    val input = "} int main {"
    val expect = "Error on line 1 col 1: }"
    assert(checkRec(input,expect,103))
  }
  test("complex program for 2 decls") {
    val input ="""int main () {
	putIntLn(4);
	putIntLn(5);
  }"""
    val expect ="sucessful"
    assert(checkRec(input,expect,104))
  }
  test("complex program more var") {
    val input ="""float a;
	int main () {
	putIntLn(4);
	putIntLn(5);
  }"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,105))
  }
  test("more functions no parameters") {
    val input ="""float a;
	void abc(){}
	int main () {
	putIntLn(4);
	putIntLn(5);
  }"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,106))
  }
  test("more functions with parameters") {
    val input ="""float a;
	void abc(int X){}
	int main () {
	putIntLn(4);
	putIntLn(5);
  }"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,107))
  }
  test("assignment op in functions") {
    val input ="""
	float a;
	void abc(){ a = 3;}
	int main () {
		putIntLn(4);
		putIntLn(5);
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,108))
  }
  test("call functions") {
    val input ="""
	float a;
	void abc(){ a = 3;}
	int main () {
		putIntLn(4);
		putIntLn(5);
		abc();
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,109))
  }
  test("repeat IF") {
    val input ="""
	float a;
	void abc(){ a = 3;}
	int main () {
		putIntLn(4);
		putIntLn(5);
		abc();
		if (a = 1) {
		}
		
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,110))
  }
  test("command return") {
    val input ="""
	float a;
	float abc(){
	a = 3;
	return 2 + 4;
	}
	int main () {
		putIntLn(4);
		putIntLn(5);
		abc();
		if (a = 1) {
		}
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,111))
  }
  test("test error") {
    val input ="""
	float a;
	int 
	float abc(){
	a = 3;
	return 2 + 4;
	}
	int main () {
		putIntLn(4);
		putIntLn(5);
		abc();
		if (a = 1) {
		}
    }
	"""
    val expect ="""sucessful"""
    assert(checkRec(input,expect,112))
  }
  
}